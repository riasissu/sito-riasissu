import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import { jsx, jsxs } from 'react/jsx-runtime';
import 'react';
import { T as Theme, C as Container, M as MediaQuery, F as FadeIn, H as HeroSlider1, $ as $$Layout } from './index_DbA3gjCu.mjs';
import styled from '@emotion/styled';
import { T as TextBox, F as Footer } from './index_BvWCuEEh.mjs';
import { H as Hero } from './index_DsBgWC0D.mjs';

const ContactStyled = styled.section`
    background: ${Theme.primary};
    padding-top: 90px;
    border-top-left-radius: 50px;
    border-top-right-radius: 50px;
    margin: -43px 0 90px;
    z-index: 1;
    position: relative;
`;
styled.div`
    max-width: 920px;
    margin: 0 auto;
`;
styled.h2`
    &,
    &:last-child {
        margin-bottom: 90px;
    }
`;
const ContainerStyled = styled(Container)`
    ${MediaQuery.min("xxxl")} {
        max-width: 920px;
    }
`;
styled.div`
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 40px;
    margin: 40px 0;

    ${MediaQuery.max("lg")} {
        grid-template-columns: 1fr;
    }
`;

const Contact = () => {
  return /* @__PURE__ */ jsx(ContactStyled, { children: /* @__PURE__ */ jsx(ContainerStyled, { children: /* @__PURE__ */ jsx(FadeIn, { delay: 0.3, children: /* @__PURE__ */ jsxs(TextBox, { variant: "background-text", bgText: "Address", boxAsLink: true, href: "mailto:xcool@riasissu.it", children: [
    /* @__PURE__ */ jsx("h3", { children: "Email" }),
    /* @__PURE__ */ jsx("p", { children: "xcool@riasissu.it" })
  ] }) }) }) });
};

const $$Contact = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Contatti", "description": "XCOOL sport event organized by RIASISSU" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "heroType": "ParallaxImage", "client:load": true, "data": {
    image: HeroSlider1.src,
    content: {
      title: "Contatti",
      paragraph: "Hai domande sul processo di iscrizione o sulla competizione? Contattaci!"
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "ContactModule", Contact, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/Contact", "client:component-export": "Contact" })} </main> ${renderComponent($$result2, "Footer", Footer, {})} ` })}`;
}, "/media/Data/Universita/RIASISSU/Xcool Udine/site/cybernetic-free/src/pages/contact.astro", void 0);

const $$file = "/media/Data/Universita/RIASISSU/Xcool Udine/site/cybernetic-free/src/pages/contact.astro";
const $$url = "/xcool/contact";

export { $$Contact as default, $$file as file, $$url as url };
