import { jsx, jsxs } from 'react/jsx-runtime';
import styled from '@emotion/styled';
import { b as createAstro, c as createComponent, r as renderTemplate, d as addAttribute, a as renderComponent, e as renderHead, f as renderSlot } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import { css, keyframes, Global } from '@emotion/react';
import { useEffect, useState, useRef } from 'react';
import 'clsx';
import './core_Buc1x485.mjs';
import react from '@vitejs/plugin-react';
import { version } from 'react-dom';
import CompressionPlugin from 'vite-plugin-compression';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { z, ZodError } from 'zod';
import { EnumChangefreq, SitemapAndIndexStream, SitemapStream } from 'sitemap';
import { createWriteStream } from 'fs';
import { resolve, normalize } from 'path';
import { Readable, pipeline } from 'stream';
import { promisify } from 'util';
import { mkdir } from 'fs/promises';
import replace from 'stream-replace-string';

const Breakpoints = {
  base: 0,
  sm: 576,
  md: 768,
  lg: 992,
  xl: 1200,
  xxl: 1440,
  xxxl: 1920
};
const MediaQuery = {
  /**
   *
   * @param breakpoint MediaQuery.min("md")
   * @returns @media example: (min-width: 768px)
   */
  min: (breakpoint) => `@media (min-width: ${Breakpoints[breakpoint]}px)`,
  /**
   *
   * @param breakpoint MediaQuery.max("lg")
   * @returns @media example: (max-width: 991px)
   */
  max: (breakpoint) => `@media (max-width: ${Breakpoints[breakpoint]}px)`,
  /**
   *
   * @param minBreakpoint MediaQuery.between("md", "lg")
   * @returns @media example: (min-width: 768px) and (max-width: 991px)
   */
  between: (minBreakpoint, maxBreakpoint) => `@media (min-width: ${Breakpoints[minBreakpoint]}px) and (max-width: ${Breakpoints[maxBreakpoint]}px)`
};

const StyledContainer = styled.div`
    margin: 0 auto;
    padding: 0 20px;
    width: 100%;

    max-width: 540px;

    ${MediaQuery.between("md", "lg")} {
        max-width: 720px;
    }

    ${MediaQuery.between("lg", "xl")} {
        max-width: 960px;
    }

    ${MediaQuery.between("xl", "xxl")} {
        max-width: 1140px;
    }

    ${MediaQuery.min("xxl")} {
        max-width: 1320px;
    }
`;

const Container = ({ children, ...rest }) => {
  if (!children) {
    return null;
  }
  return /* @__PURE__ */ jsx(StyledContainer, { ...rest, children });
};

const Colors = {
  white: "#FFFFFF",
  dark: "#101118",
  darkLighter: "#20222e"
};
const ThemeVar = css`
    :root {
        --primary: ${Colors.white};
        --secondary: ${Colors.darkLighter};
        --tertiary: ${Colors.dark};
    }
`;
const Theme = {
  primary: "var(--primary)",
  secondary: "var(--secondary)",
  tertiary: "var(--tertiary)"
};

const RobotoBlack = "/xcool/_astro/Roboto-Black.tBYbbWl-.woff2";

const RobotoBlackItalic = "/xcool/_astro/Roboto-BlackItalic.CxCOE_MU.woff2";

const RobotoBold = "/xcool/_astro/Roboto-Bold.OBUL28o9.woff2";

const RobotoBoldItalic = "/xcool/_astro/Roboto-BoldItalic.Bbs8lVH2.woff2";

const RobotoItalic = "/xcool/_astro/Roboto-Italic.0KLjOP-5.woff2";

const RobotoLight = "/xcool/_astro/Roboto-Light.-TzFADkf.woff2";

const RobotoLightItalic = "/xcool/_astro/Roboto-LightItalic.DuFP9W7P.woff2";

const RobotoMedium = "/xcool/_astro/Roboto-Medium.DRylU_ql.woff2";

const RobotoMediumItalic = "/xcool/_astro/Roboto-MediumItalic.CPqftbAj.woff2";

const RobotoRegular = "/xcool/_astro/Roboto-Regular.CjbfJjO0.woff2";

const RobotoThin = "/xcool/_astro/Roboto-Thin.Df4ydPom.woff2";

const RobotoThinItalic = "/xcool/_astro/Roboto-ThinItalic.CI9JpB2v.woff2";

var Fonts = /* @__PURE__ */ ((Fonts2) => {
  Fonts2["primary"] = `"Roboto", sans-serif`;
  return Fonts2;
})(Fonts || {});
const FontFace = css`
    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 100;
        src: url(${RobotoThin}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 300;
        src: url(${RobotoLight}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 400;
        src: url(${RobotoRegular}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 500;
        src: url(${RobotoMedium}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 700;
        src: url(${RobotoBold}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: normal;
        font-weight: 900;
        src: url(${RobotoBlack}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    // italic
    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 100;
        src: url(${RobotoThinItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }
    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 300;
        src: url(${RobotoLightItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 400;
        src: url(${RobotoItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 500;
        src: url(${RobotoMediumItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 700;
        src: url(${RobotoBoldItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
        font-family: "Roboto";
        font-style: italic;
        font-weight: 900;
        src: url(${RobotoBlackItalic}) format("woff2");
        font-display: swap;
        unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6,
            U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC,
            U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }
`;

const NormalizeCSS = css`
    ${FontFace};
    ${ThemeVar};

    :root {
        color-scheme: light only;
    }

    body,
    html {
        font-family: ${Fonts.primary};
        font-weight: 400;
        font-size: 16px;
        line-height: 1.5;
    }

    * {
        box-sizing: border-box;
    }

    html {
        line-height: 1.15;
        -webkit-text-size-adjust: 100%;
    }

    body {
        margin: 0;

        color: ${Theme.tertiary};
        background: ${Theme.primary};
        position: relative;

        &:before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: ${Theme.secondary};
            z-index: 20;
            transition: transform 0.5s;
            transition-delay: 0.2s;
        }

        &::-webkit-scrollbar {
            width: 17px;
            background: ${Theme.secondary};
        }

        &::-webkit-scrollbar-track {
            box-shadow: inset 0 0 6px rgba(0, 0, 0, 1);
        }

        &::-webkit-scrollbar-thumb {
            background-color: #7c2a04;
        }

        &.hide-overflow {
            &:before {
                transform: translateY(-100%);
            }
        }
    }

    main {
        display: block;
    }

    a {
        background-color: transparent;
    }

    abbr[title] {
        border-bottom: none;
        text-decoration: underline;
        text-decoration: underline dotted;
    }

    img {
        border-style: none;
        object-fit: cover;
    }

    button,
    input,
    optgroup,
    select,
    textarea {
        font-family: inherit; /* 1 */
        font-size: 100%; /* 1 */
        line-height: 1.15; /* 1 */
        margin: 0; /* 2 */
    }

    button,
    [type="button"],
    [type="reset"],
    [type="submit"] {
        -webkit-appearance: button;
    }

    button::-moz-focus-inner,
    [type="button"]::-moz-focus-inner,
    [type="reset"]::-moz-focus-inner,
    [type="submit"]::-moz-focus-inner {
        border-style: none;
        padding: 0;
    }

    button {
        padding: 0;
    }

    figure {
        margin: 0;
        line-height: 0;
    }

    strong {
        font-weight: 700;
    }

    a {
        text-decoration: none;
        color: inherit;
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
        margin: 0 0 30px;

        &:last-child {
            margin: 0;
        }
    }

    h1 {
        font-size: 50px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 40px;
        }
    }

    h2 {
        font-size: 45px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 35px;
        }
    }

    h3 {
        font-size: 35px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 30px;
        }
    }

    h4 {
        font-size: 25px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 25px;
        }
    }

    h5 {
        font-size: 20px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 20px;
        }
    }

    h6 {
        font-size: 18px;
        line-height: 1.2;

        ${MediaQuery.max("lg")} {
            font-size: 15px;
        }
    }

    p {
        margin: 0 0 10px;
        font-size: 16px;
        line-height: 25px;
        letter-spacing: 1px;
        color: ${Theme.tertiary};

        &:last-child {
            margin: 0;
        }
    }

    .page-404 {
        background-color: ${Theme.secondary};
        height: 100dvh;
        color: ${Theme.primary};

        p {
            color: ${Theme.primary};
        }
    }
`;

const PreviewPng = new Proxy({"src":"/xcool/_astro/preview.DZ9dn6Jb.webp","width":1326,"height":754,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/images/preview.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/images/preview.webp");
							return target[name];
						}
					});

const Logo$1 = new Proxy({"src":"/xcool/_astro/3Logo3.DOQt3VGR.png","width":514,"height":224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/images/3Logo3.png";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/images/3Logo3.png");
							return target[name];
						}
					});

new Proxy({"src":"/xcool/_astro/castello.Cmb2HOVs.jpg","width":1200,"height":800,"format":"jpg","orientation":1}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/images/castello.jpg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/images/castello.jpg");
							return target[name];
						}
					});

const Piazza = new Proxy({"src":"/xcool/_astro/piazza-liberta-udine.BSw2esS4.jpg","width":1200,"height":800,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/images/piazza-liberta-udine.jpg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/images/piazza-liberta-udine.jpg");
							return target[name];
						}
					});

new Proxy({"src":"/xcool/_astro/infinite-img-1.C1BCkNiX.webp","width":1024,"height":768,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/images/infinite-img-1.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/images/infinite-img-1.webp");
							return target[name];
						}
					});

new Proxy({"src":"/xcool/_astro/infinite-img-2.BXtCDM2h.webp","width":1024,"height":768,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/images/infinite-img-2.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/images/infinite-img-2.webp");
							return target[name];
						}
					});

const images = {
  preview: PreviewPng,
  heroImg: Logo$1,
  logo: Logo$1
};
const Image = ({
  alt,
  srcLocal,
  height,
  width,
  src,
  loading,
  ...rest
}) => {
  if (!srcLocal && !src) {
    throw new Error("srcLocal or src is required");
  }
  const image = srcLocal ? images[srcLocal] : { src, width, height };
  return /* @__PURE__ */ jsx(
    "img",
    {
      src: image.src,
      alt,
      width: width ? width : image.width,
      height: height ? height : image.height,
      loading,
      ...rest
    }
  );
};

const LogoStyled = styled.div`
    position: relative;
    z-index: 3;

    a {
        font-size: 35px;
        line-height: 30px;
        font-weight: 700;
        display: inline-flex;
        position: relative;

        span {
            &:after {
                content: "";
                position: absolute;
                bottom: -5px;
                left: 0;
                width: 25%;
                height: 3px;
                background-color: ${Theme.primary};
                z-index: 1;
                transition: width 0.2s linear;
            }
        }

        &:hover span:after {
            width: 100%;
        }

        img {
            height: 100px;
            width: 252px;
            object-fit: contain;
        }
    }
`;

const Logo = () => {
  return /* @__PURE__ */ jsx(LogoStyled, { children: /* @__PURE__ */ jsx("a", { href: "/xcool", children: /* @__PURE__ */ jsx(Image, { srcLocal: "logo", alt: "logo" }) }) });
};

const FadeInStyled = styled.div`
    opacity: 0.001;
    transform: translateY(20px);
    transition: opacity 0.5s, transform 0.5s;

    &.visible {
        opacity: 1;
        transform: translateY(0);
    }
`;
const FadeInKeyframes = keyframes`
    from {
        transform: translateY(50px);
        opacity: 0.01;
    }

    to {
        transform: translateY(0);
        opacity: 1;
    }
`;

const HeaderStyled = styled.header`
    width: 100%;

    padding: 20px 0;

    display: flex;

    justify-content: space-between;
    align-items: center;

    gap: 40px;

    position: fixed;
    top: 0;
    left: 0;
    z-index: 10;

    animation: ${FadeInKeyframes} 1s;
    animation-delay: 0.4s;
    transition: background 0.5s;

    &.scrolled {
        background: rgba(0, 0, 0, 0.8);
    }
`;
const ContainerStyled = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
    padding: 0 40px;

    ${MediaQuery.max("lg")} {
        padding: 0 20px;
    }
`;

const NavigationStyled = styled.div`
    display: flex;
    gap: 50px;

    ${MediaQuery.max("xl")} {
        gap: 20px;
    }
`;
const NavigationListWrapper = styled.nav`
    display: flex;
    align-items: center;
    justify-content: center;

    ${MediaQuery.max("lg")} {
        position: fixed;
        top: 0;
        right: -100%;

        background: ${Theme.secondary};
        height: 100dvh;
        z-index: 2;
        transform: translateX(100%);
        transition: transform 0.3s linear, right 0.7s;
        padding-top: 85px;

        width: clamp(300px, 80%, 300px);

        ${({ $isOpen }) => $isOpen && css`
                right: 0;
                transform: translateX(0);
            `};
    }
`;
const NavigationList = styled.ul`
    padding: 0;
    margin: 0;
    list-style-type: none;
    display: flex;

    ${MediaQuery.min("lg")} {
        gap: 20px;
        align-items: center;
        justify-content: center;
    }

    ${MediaQuery.max("lg")} {
        gap: 10px;
        padding: 20px 10px 53px;
        overflow: auto;
        width: 100%;
        height: 100%;

        flex-direction: column;
        justify-content: flex-start;
        align-items: flex-start;
    }

    > li a {
        text-decoration: none;
        color: ${Theme.primary};
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        line-height: 25px;
        text-transform: uppercase;
        font-weight: 900;
        letter-spacing: 1px;
        text-shadow: 1px 1px 1px rgba(0, 0, 0, 1);
        padding: 10px;
        border-radius: 5px;
        background-color: transparent;
        cursor: pointer;
        transition: background-color 0.3s, color 0.3s;

        ${MediaQuery.max("lg")} {
            padding: 10px 20px;
        }

        &:hover {
            background-color: ${Theme.primary};
            color: ${Theme.secondary};

            text-shadow: none;
        }

        img {
            margin: 0 15px 0 0;

            max-width: 30px;
            max-height: 30px;

            ${MediaQuery.max("xl")} {
                margin: 0 10px 0 0;
            }
        }
    }
`;

const HamburgerMenuButton = styled.button`
    position: relative;
    z-index: 3;

    background: ${Theme.primary};
    border-radius: 50%;
    cursor: pointer;
    transition: background 0.3s, border-color 0.3s, color 0.3s;
    width: 45px;
    height: 45px;
    border-color: transparent;

    ${MediaQuery.min("lg")} {
        display: none;
    }
`;
const HamburgerMenuButtonLine = styled.span`
    background: ${Theme.secondary};
    position: absolute;
    left: 50%;
    display: block;
    transform: translate(-50%, -50%);
    transition: transform 0.3s, background 0.3s, top 0.3s;
    pointer-events: none;

    width: 50%;
    height: 3px;

    ${MediaQuery.max("lg")} {
        height: 2px;
    }

    ${({ $open }) => $open ? css`
                  transform: translate(-50%, -50%) rotate(45deg);
                  top: 50%;
              ` : css`
                  top: calc(50% - 4px);
              `}

    &:not(:first-of-type) {
        ${({ $open }) => $open ? css`
                      transform: translate(-49%, -50%) rotate(-45deg);
                      top: 50%;
                  ` : css`
                      top: calc(50% + 4px);
                  `}
    }
`;

const Hamburger = ({ state }) => {
  const { open, setOpen } = state;
  const handleMenu = () => {
    setOpen(!open);
  };
  const handleClickOutside = (e) => {
    const target = e.target;
    if (!target.closest("nav") && open && target.tagName !== "BUTTON") {
      setOpen(false);
    }
  };
  useEffect(() => {
    if (!open)
      return;
    document.addEventListener("click", handleClickOutside);
    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, [open]);
  return /* @__PURE__ */ jsxs(
    HamburgerMenuButton,
    {
      $open: open,
      onClick: handleMenu,
      "aria-label": "Menu",
      "aria-expanded": open,
      role: "button",
      tabIndex: 0,
      children: [
        /* @__PURE__ */ jsx(HamburgerMenuButtonLine, { $open: open }),
        /* @__PURE__ */ jsx(HamburgerMenuButtonLine, { $open: open })
      ]
    }
  );
};

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  return /* @__PURE__ */ jsxs(NavigationStyled, { children: [
    /* @__PURE__ */ jsx(NavigationListWrapper, { $isOpen: isOpen, children: /* @__PURE__ */ jsxs(NavigationList, { children: [
      /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", { href: "/", children: "RIASISSU" }) }),
      /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
        "a",
        {
          href: "https://riasissu.sharepoint.com/:f:/s/xcool/EjpN4ptPglBOlpGKaguPnH8BcqPSj9pzg6nPWqCdoPsSIA?e=aqwU3a",
          target: "_blank",
          children: "Documentazione"
        }
      ) })
    ] }) }),
    /* @__PURE__ */ jsx(
      Hamburger,
      {
        state: {
          open: isOpen,
          setOpen: setIsOpen
        }
      }
    )
  ] });
};

const Header = () => {
  useEffect(() => {
    const header = document.querySelector("header");
    const handleScroll = () => {
      if (window.scrollY > 0) {
        header?.classList.add("scrolled");
      } else {
        header?.classList.remove("scrolled");
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);
  return /* @__PURE__ */ jsx(HeaderStyled, { children: /* @__PURE__ */ jsxs(ContainerStyled, { children: [
    /* @__PURE__ */ jsx(Logo, {}),
    /* @__PURE__ */ jsx(Navigation, {})
  ] }) });
};

function defineConfig(config) {
  return config;
}

const FAST_REFRESH_PREAMBLE = react.preambleCode;
function getRenderer() {
  return {
    name: "@astrojs/react",
    clientEntrypoint: version.startsWith("18.") ? "@astrojs/react/client.js" : "@astrojs/react/client-v17.js",
    serverEntrypoint: version.startsWith("18.") ? "@astrojs/react/server.js" : "@astrojs/react/server-v17.js"
  };
}
function optionsPlugin(experimentalReactChildren) {
  const virtualModule = "astro:react:opts";
  const virtualModuleId = "\0" + virtualModule;
  return {
    name: "@astrojs/react:opts",
    resolveId(id) {
      if (id === virtualModule) {
        return virtualModuleId;
      }
    },
    load(id) {
      if (id === virtualModuleId) {
        return {
          code: `export default {
						experimentalReactChildren: ${JSON.stringify(experimentalReactChildren)}
					}`
        };
      }
    }
  };
}
function getViteConfiguration({
  include,
  exclude,
  babel,
  experimentalReactChildren
} = {}) {
  return {
    optimizeDeps: {
      include: [
        version.startsWith("18.") ? "@astrojs/react/client.js" : "@astrojs/react/client-v17.js",
        "react",
        "react/jsx-runtime",
        "react/jsx-dev-runtime",
        "react-dom"
      ],
      exclude: [
        version.startsWith("18.") ? "@astrojs/react/server.js" : "@astrojs/react/server-v17.js"
      ]
    },
    plugins: [react({ include, exclude, babel }), optionsPlugin(!!experimentalReactChildren)],
    resolve: {
      dedupe: ["react", "react-dom", "react-dom/server"]
    },
    ssr: {
      external: version.startsWith("18.") ? ["react-dom/server", "react-dom/client"] : ["react-dom/server.js", "react-dom/client.js"],
      noExternal: [
        // These are all needed to get mui to work.
        "@mui/material",
        "@mui/base",
        "@babel/runtime",
        "use-immer",
        "@material-tailwind/react"
      ]
    }
  };
}
function src_default$1({
  include,
  exclude,
  babel,
  experimentalReactChildren
} = {}) {
  return {
    name: "@astrojs/react",
    hooks: {
      "astro:config:setup": ({ command, addRenderer, updateConfig, injectScript }) => {
        addRenderer(getRenderer());
        updateConfig({
          vite: getViteConfiguration({ include, exclude, babel, experimentalReactChildren })
        });
        if (command === "dev") {
          const preamble = FAST_REFRESH_PREAMBLE.replace(`__BASE__`, "/");
          injectScript("before-hydration", preamble);
        }
      }
    }
  };
}

function parseI18nUrl(url, defaultLocale, locales, base) {
  if (!url.startsWith(base)) {
    return void 0;
  }
  let s = url.slice(base.length);
  if (!s || s === "/") {
    return { locale: defaultLocale, path: "/" };
  }
  if (s[0] !== "/") {
    s = "/" + s;
  }
  const locale = s.split("/")[1];
  if (locale in locales) {
    let path = s.slice(1 + locale.length);
    if (!path) {
      path = "/";
    }
    return { locale, path };
  }
  return { locale: defaultLocale, path: s };
}

function generateSitemap(pages, finalSiteUrl, opts) {
  const { changefreq, priority, lastmod: lastmodSrc, i18n } = opts ?? {};
  const urls = [...pages];
  urls.sort((a, b) => a.localeCompare(b, "en", { numeric: true }));
  const lastmod = lastmodSrc?.toISOString();
  const { defaultLocale, locales } = i18n ?? {};
  let getI18nLinks;
  if (defaultLocale && locales) {
    getI18nLinks = createGetI18nLinks(urls, defaultLocale, locales, finalSiteUrl);
  }
  const urlData = urls.map((url, i) => ({
    url,
    links: getI18nLinks?.(i),
    lastmod,
    priority,
    changefreq
  }));
  return urlData;
}
function createGetI18nLinks(urls, defaultLocale, locales, finalSiteUrl) {
  const parsedI18nUrls = urls.map((url) => parseI18nUrl(url, defaultLocale, locales, finalSiteUrl));
  const i18nPathToLinksCache = /* @__PURE__ */ new Map();
  return (urlIndex) => {
    const i18nUrl = parsedI18nUrls[urlIndex];
    if (!i18nUrl) {
      return void 0;
    }
    const cached = i18nPathToLinksCache.get(i18nUrl.path);
    if (cached) {
      return cached;
    }
    const links = [];
    for (let i = 0; i < parsedI18nUrls.length; i++) {
      const parsed = parsedI18nUrls[i];
      if (parsed?.path === i18nUrl.path) {
        links.push({
          url: urls[i],
          lang: locales[parsed.locale]
        });
      }
    }
    if (links.length <= 1) {
      return void 0;
    }
    i18nPathToLinksCache.set(i18nUrl.path, links);
    return links;
  };
}

const SITEMAP_CONFIG_DEFAULTS = {
  entryLimit: 45e3
};

const localeKeySchema = z.string().min(1);
const SitemapOptionsSchema = z.object({
  filter: z.function().args(z.string()).returns(z.boolean()).optional(),
  customPages: z.string().url().array().optional(),
  canonicalURL: z.string().url().optional(),
  i18n: z.object({
    defaultLocale: localeKeySchema,
    locales: z.record(
      localeKeySchema,
      z.string().min(2).regex(/^[a-zA-Z\-]+$/gm, {
        message: "Only English alphabet symbols and hyphen allowed"
      })
    )
  }).refine((val) => !val || val.locales[val.defaultLocale], {
    message: "`defaultLocale` must exist in `locales` keys"
  }).optional(),
  entryLimit: z.number().nonnegative().optional().default(SITEMAP_CONFIG_DEFAULTS.entryLimit),
  serialize: z.function().args(z.any()).returns(z.any()).optional(),
  changefreq: z.nativeEnum(EnumChangefreq).optional(),
  lastmod: z.date().optional(),
  priority: z.number().min(0).max(1).optional()
}).strict().default(SITEMAP_CONFIG_DEFAULTS);

const validateOptions = (site, opts) => {
  const result = SitemapOptionsSchema.parse(opts);
  z.object({
    site: z.string().optional(),
    // Astro takes care of `site`: how to validate, transform and refine
    canonicalURL: z.string().optional()
    // `canonicalURL` is already validated in prev step
  }).refine((options) => options.site || options.canonicalURL, {
    message: "Required `site` astro.config option or `canonicalURL` integration option"
  }).parse({
    site,
    canonicalURL: result.canonicalURL
  });
  return result;
};

async function writeSitemap({
  hostname,
  sitemapHostname = hostname,
  sourceData,
  destinationDir,
  limit = 5e4,
  publicBasePath = "./"
}, astroConfig) {
  await mkdir(destinationDir, { recursive: true });
  const sitemapAndIndexStream = new SitemapAndIndexStream({
    limit,
    getSitemapStream: (i) => {
      const sitemapStream = new SitemapStream({
        hostname
      });
      const path = `./sitemap-${i}.xml`;
      const writePath = resolve(destinationDir, path);
      if (!publicBasePath.endsWith("/")) {
        publicBasePath += "/";
      }
      const publicPath = normalize(publicBasePath + path);
      let stream;
      if (astroConfig.trailingSlash === "never" || astroConfig.build.format === "file") {
        const host = hostname.endsWith("/") ? hostname.slice(0, -1) : hostname;
        const searchStr = `<loc>${host}/</loc>`;
        const replaceStr = `<loc>${host}</loc>`;
        stream = sitemapStream.pipe(replace(searchStr, replaceStr)).pipe(createWriteStream(writePath));
      } else {
        stream = sitemapStream.pipe(createWriteStream(writePath));
      }
      return [new URL(publicPath, sitemapHostname).toString(), sitemapStream, stream];
    }
  });
  let src = Readable.from(sourceData);
  const indexPath = resolve(destinationDir, `./sitemap-index.xml`);
  return promisify(pipeline)(src, sitemapAndIndexStream, createWriteStream(indexPath));
}

function formatConfigErrorMessage(err) {
  const errorList = err.issues.map((issue) => ` ${issue.path.join(".")}  ${issue.message + "."}`);
  return errorList.join("\n");
}
const PKG_NAME = "@astrojs/sitemap";
const OUTFILE = "sitemap-index.xml";
const STATUS_CODE_PAGES = /* @__PURE__ */ new Set(["404", "500"]);
function isStatusCodePage(pathname) {
  if (pathname.endsWith("/")) {
    pathname = pathname.slice(0, -1);
  }
  const end = pathname.split("/").pop() ?? "";
  return STATUS_CODE_PAGES.has(end);
}
const createPlugin = (options) => {
  let config;
  return {
    name: PKG_NAME,
    hooks: {
      "astro:config:done": async ({ config: cfg }) => {
        config = cfg;
      },
      "astro:build:done": async ({ dir, routes, pages, logger }) => {
        try {
          if (!config.site) {
            logger.warn(
              "The Sitemap integration requires the `site` astro.config option. Skipping."
            );
            return;
          }
          const opts = validateOptions(config.site, options);
          const { filter, customPages, serialize, entryLimit } = opts;
          let finalSiteUrl;
          if (config.site) {
            finalSiteUrl = new URL(config.base, config.site);
          } else {
            console.warn(
              "The Sitemap integration requires the `site` astro.config option. Skipping."
            );
            return;
          }
          let pageUrls = pages.filter((p) => !isStatusCodePage(p.pathname)).map((p) => {
            if (p.pathname !== "" && !finalSiteUrl.pathname.endsWith("/"))
              finalSiteUrl.pathname += "/";
            if (p.pathname.startsWith("/"))
              p.pathname = p.pathname.slice(1);
            const fullPath = finalSiteUrl.pathname + p.pathname;
            return new URL(fullPath, finalSiteUrl).href;
          });
          let routeUrls = routes.reduce((urls, r) => {
            if (r.type !== "page")
              return urls;
            if (r.pathname) {
              if (isStatusCodePage(r.pathname ?? r.route))
                return urls;
              let fullPath = finalSiteUrl.pathname;
              if (fullPath.endsWith("/"))
                fullPath += r.generate(r.pathname).substring(1);
              else
                fullPath += r.generate(r.pathname);
              let newUrl = new URL(fullPath, finalSiteUrl).href;
              if (config.trailingSlash === "never") {
                urls.push(newUrl);
              } else if (config.build.format === "directory" && !newUrl.endsWith("/")) {
                urls.push(newUrl + "/");
              } else {
                urls.push(newUrl);
              }
            }
            return urls;
          }, []);
          pageUrls = Array.from(/* @__PURE__ */ new Set([...pageUrls, ...routeUrls, ...customPages ?? []]));
          try {
            if (filter) {
              pageUrls = pageUrls.filter(filter);
            }
          } catch (err) {
            logger.error(`Error filtering pages
${err.toString()}`);
            return;
          }
          if (pageUrls.length === 0) {
            logger.warn(`No pages found!
\`${OUTFILE}\` not created.`);
            return;
          }
          let urlData = generateSitemap(pageUrls, finalSiteUrl.href, opts);
          if (serialize) {
            try {
              const serializedUrls = [];
              for (const item of urlData) {
                const serialized = await Promise.resolve(serialize(item));
                if (serialized) {
                  serializedUrls.push(serialized);
                }
              }
              if (serializedUrls.length === 0) {
                logger.warn("No pages found!");
                return;
              }
              urlData = serializedUrls;
            } catch (err) {
              logger.error(`Error serializing pages
${err.toString()}`);
              return;
            }
          }
          const destDir = fileURLToPath(dir);
          await writeSitemap(
            {
              hostname: finalSiteUrl.href,
              destinationDir: destDir,
              publicBasePath: config.base,
              sourceData: urlData,
              limit: entryLimit
            },
            config
          );
          logger.info(`\`${OUTFILE}\` created at \`${path.relative(process.cwd(), destDir)}\``);
        } catch (err) {
          if (err instanceof ZodError) {
            logger.warn(formatConfigErrorMessage(err));
          } else {
            throw err;
          }
        }
      }
    }
  };
};
var src_default = createPlugin;

const siteUrl = "https://riasissu.it/xcool";

const date = new Date().toISOString();
// https://astro.build/config
defineConfig({
    base: '/xcool',
    site: siteUrl + "/",

    integrations: [
        src_default$1(),
        src_default({
            serialize(item) {
                // Default values for pages
                item.priority = siteUrl + "/" === item.url ? 1.0 : 0.9;
                item.changefreq = "weekly";
                item.lastmod = date;

                // if you want to exclude a page from the sitemap, do it here
                // if (/exclude-from-sitemap/.test(item.url)) {
                //     return undefined;
                // }

                // if any page needs a different priority, changefreq, or lastmod, uncomment the following lines and adjust as needed
                // if (/test-sitemap/.test(item.url)) {
                //     item.changefreq = "daily";
                //     item.lastmod = date;
                //     item.priority = 0.9;
                // }

                // if you want to change priority of all subpages like "/posts/*", you can use:
                // if (/\/posts\//.test(item.url)) {
                //     item.priority = 0.7;
                // }
                return item;
            },
        }),
    ],
    renderers: ["@astrojs/renderer-react"],
    prerender: true,
    vite: {
        plugins: [CompressionPlugin()],
    },
    buildOptions: {
        minify: true,
    },
});

const $$Astro$1 = createAstro("https://riasissu.it/xcool/");
const $$MetaConfig = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$MetaConfig;
  const { title, description, preview } = Astro2.props;
  const metaData = {
    keywords: "astro.build, astro, static site, react, webiste templates, website creation, react templates, next.js templates, astro templates, custom website, custom website templates",
    default: {
      url: siteUrl,
      type: "website",
      title,
      description
      // image: preview,
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      image: preview,
      domain: siteUrl,
      url: siteUrl
    }
  };
  return renderTemplate`<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><!-- icons --><link rel="icon" type="image/x-icon" href="/xcool/favicon.ico"><link rel="apple-touch-icon" sizes="48x48" href="/xcool/favicon.ico"><!-- Other meta important things --><meta name="generator"${addAttribute(Astro2.generator, "content")}><meta name="description"${addAttribute(description, "content")}><meta name="color-scheme" content="light only"><meta name="keywords"${addAttribute(metaData.keywords, "content")}><meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1"><!-- default ones --><meta property="url"${addAttribute(metaData.default.url, "content")}><meta property="type"${addAttribute(metaData.default.type, "content")}><meta property="title"${addAttribute(metaData.default.title, "content")}><meta property="description"${addAttribute(metaData.default.description, "content")}><!-- <meta property="image" content={metaData.default.image as string} /> --><!-- open graph ones --><meta property="og:url"${addAttribute(metaData.default.url, "content")}><meta property="og:type"${addAttribute(metaData.default.type, "content")}><meta property="og:title"${addAttribute(metaData.default.title, "content")}><meta property="og:description"${addAttribute(metaData.default.description, "content")}><!-- <meta property="og:image" content={metaData.default.image as string} /> --><!-- twitter ones --><meta name="twitter:card"${addAttribute(metaData.twitter.card, "content")}><meta name="twitter:title"${addAttribute(metaData.twitter.title, "content")}><meta name="twitter:description"${addAttribute(metaData.twitter.description, "content")}><meta name="twitter:image"${addAttribute(metaData.twitter.image, "content")}><meta property="twitter:domain"${addAttribute(metaData.twitter.domain, "content")}><meta property="twitter:url"${addAttribute(metaData.twitter.url, "content")}>`;
}, "/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/layouts/MetaConfig.astro", void 0);

const $$Astro = createAstro("https://riasissu.it/xcool/");
const $$Layout = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Layout;
  const { title, description, overwritePreview } = Astro2.props;
  return renderTemplate`<html lang="en"> <head>${renderComponent($$result, "MetaConfig", $$MetaConfig, { "title": title, "description": description, "preview": overwritePreview ? overwritePreview : PreviewPng.src })}<title>${title}</title>${renderComponent($$result, "Global", Global, { "styles": NormalizeCSS })}${renderHead()}</head> <body> ${renderComponent($$result, "Header", Header, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/Header", "client:component-export": "Header" })} ${renderSlot($$result, $$slots["default"])} </body></html>`;
}, "/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/layouts/Layout.astro", void 0);

const convertToSeconds = (delay) => {
  return Number(delay) * 1e3;
};
const FadeIn = ({ children, delay }) => {
  const elementRef = useRef(null);
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setTimeout(() => {
              entry.target.classList.add("visible");
            }, convertToSeconds(delay ? delay : 0));
          }
        });
      },
      {
        root: null,
        rootMargin: "-50px",
        threshold: 0.1
      }
    );
    if (elementRef.current) {
      observer.observe(elementRef.current);
    }
    return () => {
      if (elementRef.current) {
        observer.unobserve(elementRef.current);
      }
    };
  }, []);
  return /* @__PURE__ */ jsx(FadeInStyled, { ref: elementRef, children });
};

const IconArrowDown = new Proxy({"src":"/xcool/_astro/icon-arrow-down.BDCzw7Ed.svg","width":30,"height":30,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/icons/icon-arrow-down.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/icons/icon-arrow-down.svg");
							return target[name];
						}
					});

const IconArrowCircle = new Proxy({"src":"/xcool/_astro/icon-arrow-circle.DUoOPlmj.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/icons/icon-arrow-circle.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/icons/icon-arrow-circle.svg");
							return target[name];
						}
					});

const IconArrowRight = new Proxy({"src":"/xcool/_astro/icon-arrow-right.DqPTpFau.svg","width":20,"height":20,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/icons/icon-arrow-right.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/icons/icon-arrow-right.svg");
							return target[name];
						}
					});

const IconFacebook = new Proxy({"src":"/xcool/_astro/icon-facebook.CiZt8951.svg","width":15,"height":32,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/icons/icon-facebook.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/icons/icon-facebook.svg");
							return target[name];
						}
					});

const IconInstagram = new Proxy({"src":"/xcool/_astro/icon-instagram.BWvvhaKh.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/icons/icon-instagram.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/icons/icon-instagram.svg");
							return target[name];
						}
					});

const IconTwitter = new Proxy({"src":"/xcool/_astro/icon-twitter.-eebusCm.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/icons/icon-twitter.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/icons/icon-twitter.svg");
							return target[name];
						}
					});

const IconLinkedIn = new Proxy({"src":"/xcool/_astro/icon-linkedin.Cr8d3BTd.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/icons/icon-linkedin.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/icons/icon-linkedin.svg");
							return target[name];
						}
					});

const IconGithub = new Proxy({"src":"/xcool/_astro/icon-github.DH9R7T2y.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/icons/icon-github.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/media/Data/Universita/RIASISSU/Xcool Udine/site/xcool/src/static/icons/icon-github.svg");
							return target[name];
						}
					});

const icons = {
  arrowDown: IconArrowDown,
  arrowCircle: IconArrowCircle,
  arrowRight: IconArrowRight,
  facebook: IconFacebook,
  instagram: IconInstagram,
  twitter: IconTwitter,
  linkedin: IconLinkedIn,
  github: IconGithub
};
const Icon = ({ alt, iconData, ...rest }) => {
  const icon = icons[iconData];
  return /* @__PURE__ */ jsx(
    "img",
    {
      src: icon.src,
      alt,
      width: icon.width,
      height: icon.height,
      "data-icon": "true",
      ...rest
    }
  );
};

const ButtonWrapper = styled.div`
    display: flex;
    justify-content: ${({ $align }) => $align || "flex-start"};
    margin-top: 20px;
`;
const ButtonLink = styled.a`
    text-transform: uppercase;
    transition: 0.3s;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
    text-align: center;
    position: relative;
    z-index: 2;

    ${({ $variant }) => $variant === "primary" && PrimaryVariant};
    ${({ $variant }) => $variant === "secondary" && SecondaryVariant};
`;
const Button$1 = ButtonLink.withComponent("button");
const PrimaryVariant = css`
    display: inline-flex;
    align-items: center;
    font-size: 25px;
    line-height: 30px;
    padding: 10px;
    margin-top: 40px;
    transition: color 0.5s;
    transition-delay: 0.2s;

    ${MediaQuery.max("lg")} {
        font-size: 14px;
        line-height: 18px;
        margin-top: 20px;
    }

    &:before {
        content: "";
        position: absolute;
        left: 0;
        top: 0;
        height: 100%;
        width: 0%;
        background: ${Theme.primary};
        z-index: -1;
        transition: width 0.5s;
    }

    &:after {
        content: "";
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 1px;
        background: ${Theme.primary};
        transition: width 0.5s;
    }

    &:hover {
        color: ${Theme.secondary};

        &:before {
            width: 100%;
        }

        &:after {
            width: 0%;
        }

        img {
            margin-right: 30px;
            opacity: 1;
        }
    }

    img {
        transition-delay: 0.2s;
        filter: invert(1);
        opacity: 0;
        margin-right: -20px;
        transition: all 0.5s;
    }
`;
const SecondaryVariant = css`
    padding: 12px 40px;
    min-width: 150px;
    border: 1.5px solid ${Theme.tertiary};
    font-size: 16px;
    line-height: 20px;
    letter-spacing: 1px;
    font-weight: 500;
    border-radius: 50px;
    background: ${Theme.tertiary};
    color: ${Theme.primary};

    &:hover {
        background: transparent;
        color: ${Theme.secondary};
    }
`;

const Button = ({
  link,
  target,
  children,
  align,
  showIcon = false,
  variant = "primary",
  asButton,
  type,
  onClick,
  ...rest
}) => {
  const ButtonComponent = asButton ? Button$1 : ButtonLink;
  return /* @__PURE__ */ jsx(ButtonWrapper, { $align: align, children: /* @__PURE__ */ jsxs(
    ButtonComponent,
    {
      href: !asButton ? link : void 0,
      target,
      onClick: asButton ? onClick : void 0,
      ...rest,
      $variant: variant,
      children: [
        showIcon && /* @__PURE__ */ jsx(Icon, { iconData: "arrowRight", alt: "arrow icon" }),
        children
      ]
    }
  ) });
};

export { $$Layout as $, Button as B, Container as C, FadeIn as F, Image as I, MediaQuery as M, Piazza as P, Theme as T, Icon as a };
