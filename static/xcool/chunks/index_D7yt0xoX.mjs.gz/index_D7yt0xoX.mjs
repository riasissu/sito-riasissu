import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import 'react/jsx-runtime';
import 'react';
import { c as Castello, $ as $$Layout } from './index_B97RYkKU.mjs';
import { H as Hero } from './index_ukJVkr-e.mjs';

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Homepage", "description": "XCOOL sport event organized by RIASISSU" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "client:load": true, "heroType": "fullPageSlider", "data": [
    {
      subtitle: "Udine - 2025",
      title: "XCOOL",
      background: Castello.src,
      paragraph: "Per ulteriori informazioni, contattaci a xcool@riasissu.it.",
      button: {
        text: "Iscriviti Qui",
        link: "/xcool/formclosed"
      }
    }
    // {
    //     subtitle: "Be Safe, Be Secure, Be Cybernetic",
    //     title: "infinite",
    //     background: HeroSlider3.src,
    //     paragraph: "",
    //     button: {
    //         text: "Take a look",
    //         link: "/infinite",
    //     },
    // },
  ], "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} </main> ` })}`;
}, "/media/Data/Universita/RIASISSU/Xcool Udine/site/cybernetic-free/src/pages/index.astro", void 0);

const $$file = "/media/Data/Universita/RIASISSU/Xcool Udine/site/cybernetic-free/src/pages/index.astro";
const $$url = "/xcool";

export { $$Index as default, $$file as file, $$url as url };
