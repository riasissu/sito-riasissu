import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import { C as ContentSection } from './index_BcFwwBDm.mjs';
import { F as FadeIn, B as Button, $ as $$Layout } from './index_DaDm5tDI.mjs';

const $$404 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "404 | Page not found", "description": "The page you are looking for might have been removed, had its name changed, or is temporarily unavailable." }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content page-404"> ${renderComponent($$result2, "ContentSection", ContentSection, { "style": {
    maxWidth: "600px",
    margin: "0 auto",
    textAlign: "center",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    height: "100%"
  } }, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "FadeIn", FadeIn, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <h1>Wooops - Soory! 404</h1> <p>
The page you are looking for might have been removed, had
                    its name changed, or is temporarily unavailable.
</p> ${renderComponent($$result4, "Button", Button, { "variant": "secondary", "showIcon": false, "link": "/xcool", "align": "center" }, { "default": ($$result5) => renderTemplate`
Go back
` })} ` })} ` })} </main> ` })}`;
}, "/media/Data/Universita/RIASISSU/Xcool Udine/site/cybernetic-free/src/pages/404.astro", void 0);

const $$file = "/media/Data/Universita/RIASISSU/Xcool Udine/site/cybernetic-free/src/pages/404.astro";
const $$url = "/xcool/404";

export { $$404 as default, $$file as file, $$url as url };
