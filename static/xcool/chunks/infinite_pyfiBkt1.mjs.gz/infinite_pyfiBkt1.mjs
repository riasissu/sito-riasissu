import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import { T as Theme, M as MediaQuery, F as FadeIn, C as Container, a as HeroSlider3, I as InfiniteImg1, b as InfiniteImg2, $ as $$Layout } from './index_ttWS0NwU.mjs';
import { H as Hero } from './index_CspCeAB0.mjs';
import { jsx, jsxs } from 'react/jsx-runtime';
import 'react';
import styled from '@emotion/styled';
import { T as TextBox, F as Footer } from './index_o1LOqjVq.mjs';

const ServiceCardsStyled = styled.section`
    background: ${Theme.primary};
    padding-top: 90px;
    border-top-left-radius: 50px;
    border-top-right-radius: 50px;
    margin: -43px 0 50px;
    z-index: 1;
    position: relative;
`;
const ServiceCardsHeading = styled.div`
    color: ${Theme.secondary};

    margin-bottom: 40px;
    max-width: 550px;

    p {
        color: ${Theme.tertiary};
    }

    h2 {
        font-size: 60px;
        line-height: 1.2;
        margin-bottom: 10px;

        ${MediaQuery.max("lg")} {
            font-size: 40px;
            line-height: 1.2;
        }
    }
`;
const ServiceCardsGrid = styled.div`
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 40px;

    ${MediaQuery.max("lg")} {
        grid-template-columns: 1fr;
        gap: 20px;
    }

    h3 {
        font-size: 20px;
        line-height: 1.2;
        margin-bottom: 5px;
    }

    p {
        margin: 0;
        font-size: 16px;
        line-height: 1.2;
        letter-spacing: -0.5px;
        opacity: 0.8;
    }
`;

const ServiceCards = ({
  cards,
  description,
  title
}) => {
  if (!cards || !cards.length) {
    return null;
  }
  const cardsElements = cards.map((card, index) => {
    return /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsxs(TextBox, { children: [
      /* @__PURE__ */ jsx("h3", { children: card.title }),
      /* @__PURE__ */ jsx("p", { children: card.description })
    ] }) }, index);
  });
  return /* @__PURE__ */ jsx(ServiceCardsStyled, { children: /* @__PURE__ */ jsxs(Container, { children: [
    title && description && /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsxs(ServiceCardsHeading, { children: [
      description && /* @__PURE__ */ jsx("p", { children: description }),
      title && /* @__PURE__ */ jsx("h2", { children: title })
    ] }) }),
    /* @__PURE__ */ jsx(ServiceCardsGrid, { children: cardsElements })
  ] }) });
};

const $$Infinite = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Cybernetic | Homepage", "description": "YOUR META DESCRIPTION FOR SEO" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "heroType": "ParallaxImage", "client:visible": true, "data": {
    image: HeroSlider3.src,
    content: {
      title: "INFINITE",
      paragraph: "Infinite is a platform that allows you to create a unlimited space for your community. It is a place where you can share your thoughts, ideas, and experiences with like-minded people."
    }
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "ServiceCards", ServiceCards, { "description": "SERVICES", "title": "The Service We Provide For You", "client:visible": true, "cards": [
    {
      title: "Cyber - development",
      description: "lorem ipsum lorem ipsum lorem ipsum lorem ipsum ."
    },
    {
      title: "Cyber - Security",
      description: "lorem ipsum lorem ipsum lorem ipsum lorem ipsum ."
    },
    {
      title: "Cyber - Marketing",
      description: "lorem ipsum lorem ipsum lorem ipsum lorem ipsum ."
    },
    {
      title: "Cyber - Development",
      description: "lorem ipsum lorem ipsum lorem ipsum lorem ipsum ."
    },
    {
      title: "Cyber - Security",
      description: "lorem ipsum lorem ipsum lorem ipsum lorem ipsum ."
    },
    {
      title: "Cyber - Marketing",
      description: "lorem ipsum lorem ipsum lorem ipsum lorem ipsum ."
    }
  ], "client:component-hydration": "visible", "client:component-path": "@modules/ServiceCards", "client:component-export": "ServiceCards" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:visible": true, "data": {
    image: {
      src: InfiniteImg1.src,
      width: 590,
      height: 300,
      alt: "Hero Image"
    },
    title: "Lets make you Infinite!",
    paragraph: "Become a part of the Infinite community and start sharing your thoughts, ideas, and experiences with like-minded people."
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:visible": true, "data": {
    switchPlaces: true,
    image: {
      src: InfiniteImg2.src,
      width: 590,
      height: 300,
      alt: "Hero Image"
    },
    title: "Infinite Community",
    paragraph: "with infinite dashboard you can easily manage your community, create posts, and interact with your followers."
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} </main> ${renderComponent($$result2, "Footer", Footer, {})} ` })}`;
}, "/media/Data/Universita/RIASISSU/Xcool Udine/site/cybernetic-free/src/pages/infinite.astro", void 0);

const $$file = "/media/Data/Universita/RIASISSU/Xcool Udine/site/cybernetic-free/src/pages/infinite.astro";
const $$url = "/it/xcool/infinite";

export { $$Infinite as default, $$file as file, $$url as url };
