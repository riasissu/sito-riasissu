import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import { jsxs, jsx } from 'react/jsx-runtime';
import 'react';
import { T as Theme, C as Container, M as MediaQuery, F as FadeIn, L as Logo, H as HeroSlider1, $ as $$Layout } from './index_DaDm5tDI.mjs';
import styled from '@emotion/styled';
import { css } from '@emotion/react';
import { H as Hero } from './index_-ejZNe5d.mjs';

const ContactStyled = styled.section`
    background: ${Theme.primary};
    padding-top: 90px;
    border-top-left-radius: 50px;
    border-top-right-radius: 50px;
    margin: -43px 0 90px;
    z-index: 1;
    position: relative;
`;
styled.div`
    max-width: 920px;
    margin: 0 auto;
`;
styled.h2`
    &,
    &:last-child {
        margin-bottom: 90px;
    }
`;
const ContainerStyled = styled(Container)`
    ${MediaQuery.min("xxxl")} {
        max-width: 920px;
    }
`;
styled.div`
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 40px;
    margin: 40px 0;

    ${MediaQuery.max("lg")} {
        grid-template-columns: 1fr;
    }
`;

const TextBotStyed = styled.div`
    padding: 30px;
    border-radius: 10px;
    background: ${Theme.primary};
    box-shadow: 0 0 10px rgb(123 123 123 / 30%);
    display: block;
    height: 100%;
    color: ${Theme.secondary};
    border-radius: 15px;

    ${(props) => props.$variant === "background-text" && TextBoxBackgroundTextVariant};
`;
const TextBoxLinkStyled = TextBotStyed.withComponent("a");
const TextBotBgText = styled.span`
    position: absolute;
    top: 0;
    right: 0;
    text-transform: uppercase;

    font-size: 90px;
    line-height: 1;
    font-weight: 900;
    letter-spacing: -7px;
    z-index: 1;
    color: ${Theme.primary};
    opacity: 0.5;

    ${MediaQuery.max("xxl")} {
        font-size: 80px;
    }

    ${MediaQuery.max("xl")} {
        font-size: 60px;
        letter-spacing: -3px;
    }
`;
const TextBotTextWrapper = styled.div`
    position: relative;
    z-index: 2;

    ${MediaQuery.max("md")} {
        max-width: 80%;
    }
`;
const TextBoxBackgroundTextVariant = css`
    position: relative;
    overflow: hidden;
    padding: 20px;

    h2,
    h3,
    h4 {
        margin-bottom: 10px;
        font-size: 20px;
        line-height: 1.2;

        &:after {
            content: none;
        }
    }

    h4,
    p {
        position: relative;
        z-index: 2;
    }

    p {
        line-height: 1.2;
    }
`;

const TextBox = ({
  children,
  variant,
  bgText,
  boxAsLink,
  ...rest
}) => {
  const TextBoxComponent = boxAsLink ? TextBoxLinkStyled : TextBotStyed;
  return /* @__PURE__ */ jsxs(TextBoxComponent, { $variant: variant, ...rest, children: [
    variant === "background-text" && bgText && /* @__PURE__ */ jsx(TextBotBgText, { children: bgText }),
    /* @__PURE__ */ jsx(TextBotTextWrapper, { children })
  ] });
};

const Contact = () => {
  return /* @__PURE__ */ jsx(ContactStyled, { children: /* @__PURE__ */ jsx(ContainerStyled, { children: /* @__PURE__ */ jsx(FadeIn, { delay: 0.3, children: /* @__PURE__ */ jsxs(TextBox, { variant: "background-text", bgText: "Address", boxAsLink: true, href: "mailto:xcool@riasissu.it", children: [
    /* @__PURE__ */ jsx("h3", { children: "Email" }),
    /* @__PURE__ */ jsx("p", { children: "xcool@riasissu.it" })
  ] }) }) }) });
};

const FooterStyled = styled.footer`
    width: 100%;

    background: ${Theme.secondary};

    padding: 90px 0;
`;
const FooterContainer = styled.div`
    display: flex;
    justify-content: space-between;

    ${MediaQuery.max("lg")} {
        flex-direction: column;
        gap: 20px;
        justify-content: center;
        align-items: center;
    }
`;
const FooterContent = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 20px;

    ${MediaQuery.max("lg")} {
        flex-direction: column;
        text-align: center;
    }

    p {
        margin: 0;
        color: ${Theme.primary};
    }
`;

const SocialsStyled = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 50px;

    margin: 50px 0 0;
`;
const SocialsList = styled.ul`
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 30px;
    padding: 0;
    margin: 0;
    width: 100%;
    list-style: none;

    ${MediaQuery.max("lg")} {
        grid-template-columns: repeat(2, 1fr);
    }

    ${MediaQuery.max("md")} {
        grid-template-columns: 1fr;
    }
`;
styled.li`
    border-radius: 50%;
    width: 100%;

    cursor: pointer;
    transition: 0.3s;
`;
styled.a`
    text-decoration: none;
    display: flex;
    justify-content: space-between;
    border-top: 1px solid ${Theme.primary};
    padding-top: 20px;
    width: 100%;
    transform: translateY(0);
    transition: transform 0.3s;

    &:hover {
        transform: translateY(-10px);
    }

    p {
        color: ${Theme.primary};
        font-size: 20px;
        line-height: 1.2;
    }

    img {
        width: 25px;
        height: 25px;
        aspect-ratio: 25/25;
        object-fit: contain;
        margin-left: 30px;
    }
`;

const Socials = ({ ...rest }) => {
  return /* @__PURE__ */ jsx(SocialsStyled, { ...rest, children: /* @__PURE__ */ jsx(SocialsList, {}) });
};

const Footer = () => {
  return /* @__PURE__ */ jsx(FooterStyled, { children: /* @__PURE__ */ jsxs(Container, { children: [
    /* @__PURE__ */ jsxs(FooterContainer, { children: [
      /* @__PURE__ */ jsx(Logo, {}),
      /* @__PURE__ */ jsx(FooterContent, {})
    ] }),
    /* @__PURE__ */ jsx(Socials, {})
  ] }) });
};

const $$Contact = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Contatti", "description": "XCOOL sport event organized by RIASISSU" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "heroType": "ParallaxImage", "client:load": true, "data": {
    image: HeroSlider1.src,
    content: {
      title: "Contatti",
      paragraph: "Hai domande sul processo di iscrizione o sulla competizione? Contattaci!"
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "ContactModule", Contact, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/Contact", "client:component-export": "Contact" })} </main> ${renderComponent($$result2, "Footer", Footer, {})} ` })}`;
}, "/media/Data/Universita/RIASISSU/Xcool Udine/site/cybernetic-free/src/pages/contact.astro", void 0);

const $$file = "/media/Data/Universita/RIASISSU/Xcool Udine/site/cybernetic-free/src/pages/contact.astro";
const $$url = "/xcool/contact";

export { $$Contact as default, $$file as file, $$url as url };
